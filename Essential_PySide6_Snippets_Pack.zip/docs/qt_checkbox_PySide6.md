---
# QCheckBox (PySide6)

**Descripción / Description:**
- ES: Ventana principal con tres QCheckBox y botón interactivo usando PySide6. Incluye layout profesional, tooltips suaves, soporte multilenguaje y validación visual.
- EN: Main window with three QCheckBox and interactive button using PySide6. Includes professional layout, smooth tooltips, multilingual support and visual validation.

**Comando de ejecución / Execution command:**
```powershell
python docs/qt_checkbox_PySide6.py
```

**Checklist técnico / Technical checklist:**
- [x] Ventana con tres QCheckBox y botón interactivo
- [x] Layout profesional y tooltips
- [x] Soporte multilenguaje
- [x] Fácil de modificar casillas y textos
- [x] Window with three QCheckBox and interactive button
- [x] Professional layout and tooltips
- [x] Multilingual support
- [x] Easy to modify checkboxes and texts

**Checklist visual / Visual checklist:**
- [x] Las tres casillas y el botón son visibles y alineados verticalmente
- [x] Al marcar/desmarcar y hacer clic en el botón, se muestra un mensaje informativo con las opciones seleccionadas
- [x] Todos los widgets permanecen visibles al cambiar el tamaño
- [x] Guarda una captura como qt_checkbox_PySide6_demo.png en assets/
- [x] The three checkboxes and button are visible and vertically aligned
- [x] Checking/unchecking and clicking the button shows an informative message with selected options
- [x] All widgets remain visible when resizing
- [x] Save a screenshot as qt_checkbox_PySide6_demo.png in assets/
