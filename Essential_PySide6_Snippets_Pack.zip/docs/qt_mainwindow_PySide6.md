
---
# QMainWindow (PySide6)

**Descripción / Description:**
- ES: Ventana principal básica usando PySide6. Incluye layout profesional, tooltips y validación visual. Bilingüe y lista para integración.
- EN: Basic main window using PySide6. Includes professional layout, tooltips, and visual validation. Bilingual and ready for integration.

**Comando de ejecución / Execution command:**
```powershell
python docs/qt_mainwindow_PySide6.py
```

**Checklist técnico / Technical checklist:**
- [x] Ventana principal básica
- [x] Layout profesional y tooltips
- [x] Fácil de modificar título y tamaño
- [x] Basic main window
- [x] Professional layout and tooltips
- [x] Easy to modify title and size

**Checklist visual / Visual checklist:**
- [x] La ventana aparece con el título y tamaño correctos
- [x] Widgets permanecen visibles al redimensionar
- [x] Captura de pantalla guardada como qt_mainwindow_PySide6_demo.png en assets/
- [x] The window appears with the correct title and size
- [x] Widgets remain visible when resizing
- [x] Screenshot saved as qt_mainwindow_PySide6_demo.png in assets/
- PySide6 >= 5.10
