
"""
QLineEdit (PySide6)

Bilingual Documentation / Documentación Bilingüe
------------------------------------------------
EN: Professional snippet to create a main window with a QLineEdit and a button using PySide6. Includes smooth tooltips, minimum size, and best practices for professional use.

ES: Snippet profesional para crear una ventana principal con un QLineEdit y un botón usando PySide6. Incluye tooltips suaves, tamaño mínimo y buenas prácticas para uso profesional.

Example / Ejemplo:
------------------
EN:
    from docs.qt_lineedit_PySide6 import MainWindow
    app = QApplication([])
    window = MainWindow()
    window.show()
    app.exec_()

ES:
    from docs.qt_lineedit_PySide6 import MainWindow
    app = QApplication([])
    window = MainWindow()
    window.language = "es"
    window.show()
    app.exec_()
"""


from typing import Optional
from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QLineEdit,
    QPushButton,
    QMessageBox,
    QToolTip,
    QStatusBar,
)
from PySide6.QtCore import QTimer, QEvent
from PySide6.QtGui import QEnterEvent
import sys


class SmoothTooltipButton(QPushButton):
    def __init__(self, text: str, tooltip: str, parent: Optional[QWidget] = None) -> None:
        super().__init__(text, parent)
        self._tooltip = tooltip
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._show_tooltip)
        self.setMouseTracking(True)

    def enterEvent(self, event: QEnterEvent) -> None:
        self._timer.start(80)
        super().enterEvent(event)

    def leaveEvent(self, event: QEvent) -> None:
        QToolTip.hideText()
        self._timer.stop()
        super().leaveEvent(event)

    def _show_tooltip(self) -> None:
        QToolTip.showText(self.mapToGlobal(self.rect().center()), self._tooltip, self)




class MainWindow(QMainWindow):
    """
    EN: Main window for QLineEdit snippet. Demonstrates a line edit and button with tooltips, and professional layout. Multilingual support included.
    ES: Ventana principal para el snippet QLineEdit. Demuestra un campo de texto y botón con tooltips y layout profesional. Incluye soporte multilenguaje.
    """

    language: str = "en"  # Default language is English. Change to 'es' for Spanish.

    def __init__(self) -> None:
        super().__init__()
        if self.language == "es":
            self.setWindowTitle("QLineEdit (PySide6)")
            lineedit_tooltip = "Introduce texto aquí"
            button_text = "Mostrar texto"
            button_tooltip = "Haz clic para mostrar el texto ingresado"
            msg_title = "Texto"
            msg_fmt = "Ingresaste: {}"
        else:
            self.setWindowTitle("QLineEdit (PySide6)")
            lineedit_tooltip = "Enter text here"
            button_text = "Show Text"
            button_tooltip = "Click to show entered text"
            msg_title = "Text"
            msg_fmt = "You entered: {}"
        self.setMinimumSize(300, 150)
        self.setMaximumSize(600, 350)
        self.resize(400, 200)
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        self.lineEdit = QLineEdit(self)
        self.lineEdit.setToolTip(lineedit_tooltip)
        layout.addWidget(self.lineEdit)
        self.button = SmoothTooltipButton(button_text, button_tooltip, self)
        self.button.clicked.connect(self.show_text)
        layout.addWidget(self.button)
        self.msg_title = msg_title
        self.msg_fmt = msg_fmt
        # Añadir QStatusBar para grip profesional (Qt lo gestiona automáticamente)
        status_bar = QStatusBar(self)
        self.setStatusBar(status_bar)

    def show_text(self) -> None:
        text = self.lineEdit.text()
        QMessageBox.information(self, self.msg_title, self.msg_fmt.format(text))


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
