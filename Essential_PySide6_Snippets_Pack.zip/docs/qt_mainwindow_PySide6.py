"""
QMainWindow (PySide6)

Bilingual Documentation / Documentación Bilingüe
------------------------------------------------
EN: Professional snippet to create a basic main window using PySide6. Includes minimum size, short title, and best practices for professional use.

ES: Snippet profesional para crear una ventana principal básica usando PySide6. Incluye tamaño mínimo, título corto y buenas prácticas para uso profesional.

Example / Ejemplo:
------------------
EN:
    from docs.qt_mainwindow_PySide6 import MainWindow
    app = QApplication([])
    window = MainWindow()
    window.show()
    app.exec_()

ES:
    from docs.qt_mainwindow_PySide6 import MainWindow
    app = QApplication([])
    window = MainWindow()
    window.language = "es"
    window.show()
    app.exec_()
"""

from PySide6.QtWidgets import QApplication, QMainWindow, QStatusBar
import sys



from typing import Optional


class MainWindow(QMainWindow):
    """
    EN: Professional main window with minimum size and status bar. Bilingual support.
    ES: Ventana principal profesional con tamaño mínimo y barra de estado. Soporte bilingüe.
    """

    language: str = "en"  # Default language is English. Change to 'es' for Spanish.

    def __init__(self) -> None:
        super().__init__()
        if self.language == "es":
            self.setWindowTitle("Ventana Principal (PySide6)")
        else:
            self.setWindowTitle("Main Window (PySide6)")
        self.setMinimumSize(800, 600)
        self.resize(800, 600)
        # Añadir QStatusBar para grip profesional (Qt lo gestiona automáticamente)
        status_bar = QStatusBar(self)
        self.setStatusBar(status_bar)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
