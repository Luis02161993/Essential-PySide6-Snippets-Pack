"""
QComboBox (PySide6) - Pruebas Automáticas / Automated Tests
---------------------------------------------------------
EN: Automated tests for the QComboBox snippet using pytest-qt. Includes launch, language, size limits, and widget existence tests. Professional coverage and bilingual docstring.
ES: Pruebas automáticas para el snippet QComboBox usando pytest-qt. Incluye pruebas de lanzamiento, idioma, límites de tamaño y existencia de widgets. Cobertura profesional y docstring bilingüe.
"""
import pytest
from PySide6.QtWidgets import QApplication
from docs.qt_combobox_PySide6 import MainWindow


@pytest.fixture
def app():
    import sys

    app = QApplication.instance() or QApplication(sys.argv)
    yield app


@pytest.mark.parametrize(
    "lang,title",
    [
        ("en", "ComboBox - QtRapidKit"),
        ("es", "ComboBox - QtRapidKit"),
    ],
)
def test_mainwindow_title(qapp, qtbot, lang, title):
    MainWindow.language = lang
    win = MainWindow()
    qtbot.addWidget(win)
    win.show()
    assert win.windowTitle() == title
    win.close()


@pytest.mark.parametrize("lang", ["en", "es"])
def test_mainwindow_resize_limits(qapp, qtbot, lang):
    MainWindow.language = lang
    win = MainWindow()
    qtbot.addWidget(win)
    win.show()
    assert win.minimumWidth() >= 300
    assert win.minimumHeight() >= 140
    assert win.width() >= win.minimumWidth()
    assert win.height() >= win.minimumHeight()
    win.close()


@pytest.mark.parametrize("lang", ["en", "es"])
def test_combobox_and_button_exist(qapp, qtbot, lang):
    MainWindow.language = lang
    win = MainWindow()
    qtbot.addWidget(win)
    win.show()
    assert hasattr(win, "combo")
    assert hasattr(win, "button")
    assert win.combo is not None
    assert win.button is not None
    win.close()
