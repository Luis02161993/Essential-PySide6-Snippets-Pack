---
# QLineEdit (PySide6)

**Descripción / Description:**
- ES: Ventana principal con QLineEdit y botón para mostrar el texto ingresado usando PySide6. Incluye layout profesional, tooltips y validación visual. Bilingüe y lista para integración.
- EN: Main window with QLineEdit and a button to show the entered text using PySide6. Includes professional layout, tooltips, and visual validation. Bilingual and ready for integration.

**Comando de ejecución / Execution command:**
```powershell
python docs/qt_lineedit_PySide6.py
```

**Checklist técnico / Technical checklist:**
- [x] Ventana con tamaño mínimo profesional
- [x] QLineEdit y botón visibles y alineados
- [x] Tooltips en ambos widgets
- [x] Fácil de modificar textos y propiedades
- [x] Window with professional minimum size
- [x] QLineEdit and button visible and aligned
- [x] Tooltips on both widgets
- [x] Easy to modify texts and properties

**Checklist visual / Visual checklist:**
- [x] La ventana aparece con el título y tamaño correctos
- [x] QLineEdit y botón visibles y alineados
- [x] Tooltips aparecen al pasar el mouse
- [x] Al ingresar texto y presionar el botón se muestra el diálogo modal
- [x] Widgets permanecen visibles al redimensionar
- [x] Captura de pantalla guardada como qt_lineedit_PySide6_demo.png en assets/
- [x] The window appears with the correct title and size
- [x] QLineEdit and button are visible and aligned
- [x] Tooltips appear when hovering over each widget
- [x] Entering text and clicking the button shows the modal dialog
- [x] Widgets remain visible when resizing
- [x] Screenshot saved as qt_lineedit_PySide6_demo.png in assets/
