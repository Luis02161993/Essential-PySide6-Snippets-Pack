"""
QCalendarWidget (PySide6) - Pruebas Automáticas / Automated Tests
---------------------------------------------------------------
EN: Automated tests for the QCalendarWidget snippet using pytest-qt. Includes launch, language, size limits, label update, and widget existence tests. Professional coverage and bilingual docstring.
ES: Pruebas automáticas para el snippet QCalendarWidget usando pytest-qt. Incluye pruebas de lanzamiento, idioma, límites de tamaño, actualización de etiqueta y existencia de widgets. Cobertura profesional y docstring bilingüe.
"""
import pytest
from PySide6.QtWidgets import QApplication
from docs.qt_calendarwidget_PySide6 import MainWindow


@pytest.mark.parametrize(
    "lang,title",
    [
        ("en", "Qt Calendar - QtRapidKit"),
        ("es", "Calendario Qt - QtRapidKit"),
    ],
)
def test_mainwindow_title_and_launch(qtbot, lang, title):
    MainWindow.language = lang
    window = MainWindow()
    qtbot.addWidget(window)
    window.show()
    assert window.windowTitle() == title
    assert window.isVisible()
    window.close()


@pytest.mark.parametrize("lang", ["en", "es"])
def test_mainwindow_resize_limits(qtbot, lang):
    MainWindow.language = lang
    window = MainWindow()
    qtbot.addWidget(window)
    window.show()
    assert window.minimumWidth() >= 400
    assert window.minimumHeight() >= 350
    assert window.maximumWidth() <= 650
    assert window.maximumHeight() <= 550
    window.close()


@pytest.mark.parametrize(
    "lang,label_prefix", [
        ("en", "Selected date: "),
        ("es", "Fecha seleccionada: "),
    ]
)
def test_label_updates_on_date_change(qapp, qtbot, lang, label_prefix):
    MainWindow.language = lang
    window = MainWindow()
    qtbot.addWidget(window)
    window.show()
    window.calendar.setSelectedDate(window.calendar.minimumDate())
    date = window.calendar.selectedDate()
    window.update_label()
    if lang == "es":
        expected = f"{label_prefix}{date.toString('dd/MM/yyyy')}"
    else:
        expected = f"{label_prefix}{date.toString('yyyy-MM-dd')}"
    assert window.label.text() == expected
    window.close()


@pytest.mark.parametrize("lang", ["en", "es"])
def test_widgets_exist(qapp, qtbot, lang):
    MainWindow.language = lang
    window = MainWindow()
    qtbot.addWidget(window)
    window.show()
    assert hasattr(window, "calendar")
    assert hasattr(window, "label")
    assert window.calendar is not None
    assert window.label is not None
    window.close()
