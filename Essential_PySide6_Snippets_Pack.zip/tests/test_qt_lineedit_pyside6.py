"""
Pruebas automáticas para qt_lineedit_PySide6.py usando pytest-qt.
Incluye pruebas de:
- Lanzamiento de la ventana principal
- Cambio de idioma (si aplica)
"""
import pytest
from PySide6.QtWidgets import QApplication
from docs.qt_lineedit_PySide6 import MainWindow

@pytest.fixture
def main_window(qtbot):
    window = MainWindow()
    qtbot.addWidget(window)
    window.show()
    return window

def test_window_launch(main_window):
    assert main_window.isVisible()
    assert main_window.windowTitle() != ""

# Si el snippet soporta multilenguaje, agregar prueba similar a la de grid_layout:
def test_language_switch_to_spanish(qtbot):
    if not hasattr(MainWindow, 'language'):
        pytest.skip("Este snippet no soporta multilenguaje.")
    class SpanishMainWindow(MainWindow):
        language = "es"
    window = SpanishMainWindow()
    qtbot.addWidget(window)
    window.show()
    assert window.windowTitle() != ""
