

# PySide6 Professional Snippets Pack

## ENGLISH

**PySide6 Professional Snippets Pack** is a production-ready, open-source collection of code snippets for rapid, professional Qt GUI development in Python. All documentation, code comments, and examples are bilingual (EN/ES), but this section is fully in English for clarity. See the Spanish section below for a complete translation.

### Features
- Bilingual docstrings and documentation (EN/ES)
- Clean, professional, PEP8-compliant code
- Automated tests (pytest, pytest-qt)
- Ready-to-use assets (icons, screenshots)
- Professional structure and real-world examples
- Free and open source (MIT License)

### Quick Start
```bash
pip install -r requirements.txt
pytest
```

### Usage Example
```python
from smooth_tooltip_button_and_palette import SmoothTooltipButton, set_auto_palette
```

### Structure
- `docs/`: Documentation and use cases
- `tests/`: Automated tests
- `assets/`: Logos, icons, screenshots
- `src/`: Snippets and main modules

### License
MIT (see LICENSE)

### Contact
LUIS_G-021693 (2025)
Email: gluis476@yhaoo.com

---

### Note on Skipped Tests

There is a test marked as "skipped" in `tests/test_snippet_methods.py`. This happens because the safe methods list is empty: all relevant snippet methods require user interaction (e.g., opening dialogs or windows), which is not safe to automate without a proper GUI environment. The test is kept to facilitate future extensions if pure logic methods are added.

---

## ESPAÑOL

**Paquete Profesional de Snippets PySide6** es una colección lista para producción y de código abierto de fragmentos de código para desarrollo rápido y profesional de interfaces Qt en Python. Toda la documentación, comentarios y ejemplos son bilingües (EN/ES), pero esta sección está completamente en español para mayor claridad. Consulta la sección en inglés arriba para la versión original.

### Características
- Docstrings y documentación bilingüe (EN/ES)
- Código limpio, profesional y conforme a PEP8
- Pruebas automáticas (pytest, pytest-qt)
- Assets listos para usar (íconos, capturas)
- Estructura profesional y ejemplos reales
- Libre y de código abierto (Licencia MIT)

### Inicio rápido
```bash
pip install -r requirements.txt
pytest
```

### Ejemplo de uso
```python
from smooth_tooltip_button_and_palette import SmoothTooltipButton, set_auto_palette
```

### Estructura
- `docs/`: Documentación y casos de uso
- `tests/`: Pruebas automáticas
- `assets/`: Logos, íconos, capturas
- `src/`: Snippets y módulos principales

### Licencia
MIT (ver LICENSE)

### Contacto
LUIS_G-021693 (2025)
Correo: gluis476@yhaoo.com

---

### Nota sobre tests skipped

Existe un test marcado como "skipped" en `tests/test_snippet_methods.py`. Esto ocurre porque la lista de métodos seguros está vacía: todos los métodos relevantes de los snippets requieren interacción de usuario (por ejemplo, abrir diálogos o ventanas), lo cual no es seguro automatizar sin un entorno gráfico adecuado. El test se mantiene para facilitar futuras ampliaciones si se agregan métodos lógicos puros.
