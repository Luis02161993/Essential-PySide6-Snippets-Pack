"""
Módulo de snippet para QComboBox (PySide6)
"""
from PySide6.QtWidgets import QMainWindow, QComboBox, QVBoxLayout, QWidget, QPushButton, QMessageBox, QStatusBar
from typing import Optional



from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QComboBox,
    QPushButton,
    QMessageBox,
    QToolTip,
    QStatusBar,
    QStyleFactory,
)
from PySide6.QtCore import QTimer
from PySide6.QtGui import QColor, QPalette
import sys
from typing import Optional

def set_auto_palette(app: QApplication) -> None:
    """
    EN: Set the application palette to match the system's dark/light mode automatically.
    ES: Ajusta la paleta de la aplicación para coincidir con el modo oscuro/claro del sistema automáticamente.
    (PySide6 professional snippet)
    """
    app.setStyle(QStyleFactory.create("Fusion"))
    app.setPalette(QApplication.style().standardPalette())



class SmoothTooltipButton(QPushButton):
    """
    EN: QPushButton with smooth tooltip on hover. Professional, typed, and reusable.
    ES: QPushButton con tooltip suave al pasar el mouse. Profesional, tipado y reutilizable.
    """
    def __init__(self, text: str, tooltip: str, parent: 'Optional[QWidget]' = None) -> None:
        super().__init__(text, parent)
        self._tooltip: str = tooltip
        self._timer: QTimer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._show_tooltip)
        self.setMouseTracking(True)

    def enterEvent(self, event) -> None:
        self._timer.start(80)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        QToolTip.hideText()
        self._timer.stop()
        super().leaveEvent(event)

    def _show_tooltip(self) -> None:
        QToolTip.showText(self.mapToGlobal(self.rect().center()), self._tooltip, self)



class MainWindow(QMainWindow):
    """
    EN: Main window for QComboBox snippet. Demonstrates a combobox and selection button with tooltips. All elements use a professional layout. Multilingual support included. (PySide6)
    ES: Ventana principal para el snippet QComboBox. Demuestra un combobox y botón de selección con tooltips. Todos los elementos usan un layout profesional. Incluye soporte multilenguaje. (PySide6)
    """

    language: str = "en"  # Default language is English. Change to 'es' for Spanish.
    combo: QComboBox
    button: SmoothTooltipButton

    def __init__(self) -> None:
        super().__init__()
        if type(self).language == "es":
            self.setWindowTitle("ComboBox - QtRapidKit")
            combo_items = ["Opción 1", "Opción 2", "Opción 3"]
            combo_tooltip = "Selecciona una opción (PySide6)"
            button_text = "Mostrar selección"
            button_tooltip = "Haz clic para mostrar la opción seleccionada (PySide6)"
        else:
            self.setWindowTitle("ComboBox - QtRapidKit")
            combo_items = ["Option 1", "Option 2", "Option 3"]
            combo_tooltip = "Select an option (PySide6)"
            button_text = "Show Selection"
            button_tooltip = "Click to show selected option (PySide6)"
        self.setMinimumSize(300, 150)
        self.resize(400, 200)
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        self.combo = QComboBox(self)
        self.combo.setToolTip(combo_tooltip)
        self.combo.addItems(combo_items)
        layout.addWidget(self.combo)
        self.comboBox = self.combo  # Para el test de atributo
        self.button = SmoothTooltipButton(button_text, button_tooltip, self)
        self.button.clicked.connect(self.show_selection)
        layout.addWidget(self.button)
        status_bar = QStatusBar(self)
        self.setStatusBar(status_bar)

    def show_selection(self) -> None:
        selection = self.combo.currentText()
        if self.language == "es":
            QMessageBox.information(self, "Selección", f"Seleccionado: {selection}")
        else:
            QMessageBox.information(self, "Selection", f"Selected: {selection}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    set_auto_palette(app)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
