---
# QHBoxLayout (PySide6)

**Descripción / Description:**
- ES: Ventana principal con layout horizontal y tres botones interactivos usando PySide6. Incluye layout profesional, tooltips y validación visual. Bilingüe y lista para integración.
- EN: Main window with horizontal layout and three interactive buttons using PySide6. Includes professional layout, tooltips, and visual validation. Bilingual and ready for integration.

**Comando de ejecución / Execution command:**
```powershell
python docs/qt_horizontal_layout_PySide6.py
```

**Checklist técnico / Technical checklist:**
- [x] Ventana con tamaño mínimo profesional
- [x] Layout horizontal y tres botones interactivos
- [x] Tooltips y layout profesional
- [x] Fácil de modificar botones y textos
- [x] Window with professional minimum size
- [x] Horizontal layout and three interactive buttons
- [x] Tooltips and professional layout
- [x] Easy to modify buttons and texts

**Checklist visual / Visual checklist:**
- [x] La ventana aparece con el título y tamaño correctos
- [x] Tres botones visibles y alineados horizontalmente
- [x] Tooltips aparecen al pasar el mouse
- [x] Al hacer clic en cada botón se muestra el mensaje correcto
- [x] Todos los widgets permanecen visibles al redimensionar
- [x] Captura de pantalla guardada como qt_horizontal_layout_PySide6_demo.png en assets/
- [x] The window appears with the correct title and size
- [x] All three buttons are visible and horizontally aligned
- [x] Tooltips appear when hovering over each button
- [x] Clicking each button shows the correct message
- [x] All widgets remain visible when resizing the window
- [x] Screenshot saved as qt_horizontal_layout_PySide6_demo.png in assets/
