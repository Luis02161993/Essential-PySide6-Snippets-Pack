from typing import Optional
"""
QDialog (PySide6)

Bilingual Documentation / Documentación Bilingüe
------------------------------------------------
EN: Professional snippet to create a custom QDialog with a label and two buttons using PySide6. Includes smooth tooltips, minimum size, and best practices for professional use.

ES: Snippet profesional para crear un QDialog personalizado con una etiqueta y dos botones usando PySide6. Incluye tooltips suaves, tamaño mínimo y buenas prácticas para uso profesional.

Example / Ejemplo:
------------------
EN:
    from docs.qt_dialog_PySide6 import MainWindow
    app = QApplication([])
    dlg = MainWindow()
    if dlg.exec_() == dlg.Accepted:
        print("Accepted")
    else:
        print("Cancelled")

ES:
    from docs.qt_dialog_PySide6 import MainWindow
    app = QApplication([])
    dlg = MainWindow()
    dlg.language = "es"
    if dlg.exec_() == dlg.Accepted:
        print("Aceptado")
    else:
        print("Cancelado")
"""

from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QVBoxLayout,
    QPushButton,
    QLabel,
    QToolTip,
    QMessageBox,
    QHBoxLayout,
    QSpacerItem,
    QSizePolicy,
)
from PySide6.QtCore import Qt, QTimer, QEvent
import sys


class SmoothTooltipButton(QPushButton):
    def __init__(self, text: str, tooltip: str, parent: Optional[QDialog] = None) -> None:
        super().__init__(text, parent)
        self._tooltip: str = tooltip
        self._timer: QTimer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._show_tooltip)
        self.setMouseTracking(True)

    def enterEvent(self, event) -> None:
        self._timer.start(80)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        QToolTip.hideText()
        self._timer.stop()
        super().leaveEvent(event)

    def _show_tooltip(self) -> None:
        QToolTip.showText(self.mapToGlobal(self.rect().center()), self._tooltip, self)



from typing import Optional


class CustomDialog(QDialog):
    """
    EN: Custom dialog for QDialog snippet. Demonstrates a label and two buttons with tooltips. Professional layout and multilingual support included.
    ES: Diálogo personalizado para el snippet QDialog. Demuestra una etiqueta y dos botones con tooltips. Layout profesional y soporte multilenguaje incluidos.
    """

    language: str = "en"  # Default language is English. Change to 'es' for Spanish.
    label: QLabel
    buttonBox: list
    SmoothTooltipButton = SmoothTooltipButton

    def __init__(self, parent: Optional[QDialog] = None) -> None:
        super().__init__(parent)
        if self.language == "es":
            self.setWindowTitle("Diálogo Personalizado - QtRapidKit")
            label_text = "Este es un diálogo personalizado."
            ok_text = "Aceptar"
            ok_tooltip = "Aceptar y cerrar el diálogo"
            cancel_text = "Cancelar"
            cancel_tooltip = "Cancelar y cerrar el diálogo"
            result_title = "Resultado"
            result_accepted = "¡Diálogo aceptado!"
            result_cancelled = "¡Diálogo cancelado!"
        else:
            self.setWindowTitle("Custom QDialog - QtRapidKit")
            label_text = "This is a custom dialog."
            ok_text = "OK"
            ok_tooltip = "Accept and close dialog"
            cancel_text = "Cancel"
            cancel_tooltip = "Cancel and close dialog"
            result_title = "Result"
            result_accepted = "Dialog accepted!"
            result_cancelled = "Dialog cancelled!"
        self.result_title = result_title
        self.result_accepted = result_accepted
        self.result_cancelled = result_cancelled
        self.setMinimumSize(300, 140)
        self.setMaximumSize(600, 320)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addSpacerItem(QSpacerItem(0, 50, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed))
        self.label = QLabel(label_text, self)
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.label)
        layout.addSpacerItem(QSpacerItem(0, 7, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed))
        layout.addSpacerItem(QSpacerItem(0, 0, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding))
        btn_ok = SmoothTooltipButton(ok_text, ok_tooltip, self)
        btn_ok.clicked.connect(self.accept)
        btn_cancel = SmoothTooltipButton(cancel_text, cancel_tooltip, self)
        btn_cancel.clicked.connect(self.reject)
        self.buttonBox = [btn_ok, btn_cancel]
        btn_row = QHBoxLayout()
        btn_row.setContentsMargins(16, 0, 16, 0)
        btn_row.addWidget(btn_cancel)
        btn_row.addStretch(1)
        btn_row.addWidget(btn_ok)
        layout.addLayout(btn_row)
        layout.addSpacerItem(QSpacerItem(0, 12, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed))
        # NOTA: QDialog no soporta QStatusBar ni grip profesional de redimensión.
        # Si necesitas grip, usa QMainWindow. El sistema operativo gestiona el borde de redimensión en QDialog.


MainWindow = CustomDialog  # Para compatibilidad con los tests que esperan MainWindow
SmoothTooltipButton = SmoothTooltipButton  # Exportar para los tests

if __name__ == "__main__":
    app = QApplication(sys.argv)
    dlg = CustomDialog()
    if dlg.exec_() == QDialog.DialogCode.Accepted:
        QMessageBox.information(None, dlg.result_title, dlg.result_accepted)
    else:
        QMessageBox.information(None, dlg.result_title, dlg.result_cancelled)
    sys.exit()
