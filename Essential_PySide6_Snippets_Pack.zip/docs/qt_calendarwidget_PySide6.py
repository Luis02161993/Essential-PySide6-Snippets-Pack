"""
QCalendarWidget (PySide6)

Bilingual Documentation / Documentación Bilingüe
------------------------------------------------
EN: Professional snippet to create a main window with a QCalendarWidget and a label showing the selected date using PySide6. Includes smooth tooltips, minimum size, and best practices for professional use.

ES: Snippet profesional para crear una ventana principal con un QCalendarWidget y una etiqueta mostrando la fecha seleccionada usando PySide6. Incluye tooltips suaves, tamaño mínimo y buenas prácticas para uso profesional.

Example / Ejemplo:
------------------
EN:
    from docs.qt_calendarwidget_PySide6 import MainWindow
    app = QApplication([])
    window = MainWindow()
    window.show()
    app.exec_()

ES:
    from docs.qt_calendarwidget_PySide6 import MainWindow
    app = QApplication([])
    window = MainWindow()
    window.language = "es"
    window.show()
    app.exec_()
"""

import sys
from PySide6.QtWidgets import (
    QApplication,
    QWidget,
    QMainWindow,
    QCalendarWidget,
    QLabel,
    QSizePolicy,
    QVBoxLayout,
    QStatusBar,
    QStyleFactory,
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPalette

def set_auto_palette(app: QApplication) -> None:
    """
    EN: Set the application palette to match the system's dark/light mode automatically.
    ES: Ajusta la paleta de la aplicación para coincidir con el modo oscuro/claro del sistema automáticamente.
    """
    app.setStyle(QStyleFactory.create("Fusion"))
    app.setPalette(QApplication.style().standardPalette())




from typing import Optional


class MainWindow(QMainWindow):
    """
    EN: Main window with a QCalendarWidget and a label showing the selected date. Professional layout, tooltips, and bilingual support.
    ES: Ventana principal con QCalendarWidget y una etiqueta mostrando la fecha seleccionada. Layout profesional, tooltips y soporte bilingüe.
    """

    language: str = "en"  # Default language is English. Change to 'es' for Spanish.
    label: QLabel
    calendar: QCalendarWidget

    def __init__(self) -> None:
        super().__init__()
        if self.language == "es":
            self.setWindowTitle("Calendario Qt - QtRapidKit")
            label_text = "Selecciona una fecha"
        else:
            self.setWindowTitle("Qt Calendar - QtRapidKit")
            label_text = "Select a date"
        self.setMinimumSize(420, 380)
        self.setMaximumSize(600, 500)
        central = QWidget(self)
        layout = QVBoxLayout(central)
        self.label = QLabel(f"{label_text}", self)
        layout.addWidget(self.label, alignment=Qt.AlignmentFlag.AlignHCenter)
        self.calendar = QCalendarWidget(self)
        self.calendar.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.calendar.selectionChanged.connect(self.update_label)
        layout.addWidget(self.calendar)
        # Tooltips minimalistas para flechas de navegación
        nav_bar = self.calendar.findChild(QWidget, "qt_calendar_navigationbar")
        if nav_bar:
            for child in nav_bar.findChildren(QWidget):
                if child.toolTip() or child.whatsThis():
                    continue
                if hasattr(child, "setToolTip"):
                    if child.objectName().startswith("qt_calendar_prevmonth"):
                        child.setToolTip("◀ Previous month")
                    elif child.objectName().startswith("qt_calendar_nextmonth"):
                        child.setToolTip("Next month ▶")
                    elif child.objectName().startswith("qt_calendar_prevyear"):
                        child.setToolTip("« Previous year")
                    elif child.objectName().startswith("qt_calendar_nextyear"):
                        child.setToolTip("Next year »")
        self.setCentralWidget(central)
        # Añadir QStatusBar para grip profesional (Qt lo gestiona automáticamente)
        status_bar = QStatusBar(self)
        self.setStatusBar(status_bar)
        self.update_label()

    def update_label(self) -> None:
        date = self.calendar.selectedDate()
        if self.language == "es":
            self.label.setText(f"Fecha seleccionada: {date.toString('dd/MM/yyyy')}")
        else:
            self.label.setText(f"Selected date: {date.toString('yyyy-MM-dd')}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    set_auto_palette(app)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())
