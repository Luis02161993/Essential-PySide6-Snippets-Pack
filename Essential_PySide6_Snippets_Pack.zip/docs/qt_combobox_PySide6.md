---
# QComboBox (PySide6)

**Descripción / Description:**
- ES: Ventana principal con QComboBox y botón para mostrar la opción seleccionada usando PySide6. Incluye layout profesional, tooltips y validación visual. Bilingüe y lista para integración.
- EN: Main window with QComboBox and a button to show the selected option using PySide6. Includes professional layout, tooltips, and visual validation. Bilingual and ready for integration.

**Comando de ejecución / Execution command:**
```powershell
python docs/qt_combobox_PySide6.py
```

**Checklist técnico / Technical checklist:**
- [x] Ventana con tamaño mínimo profesional
- [x] QComboBox y botón visibles y alineados
- [x] Tooltips en ambos widgets
- [x] Fácil de modificar textos y opciones
- [x] Window with professional minimum size
- [x] QComboBox and button visible and aligned
- [x] Tooltips on both widgets
- [x] Easy to modify texts and options

**Checklist visual / Visual checklist:**
- [x] La ventana aparece con el título y tamaño correctos
- [x] QComboBox y botón visibles y alineados
- [x] Tooltips aparecen al pasar el mouse
- [x] Al seleccionar una opción y presionar el botón se muestra el diálogo modal
- [x] Widgets permanecen visibles al redimensionar
- [x] Captura de pantalla guardada como qt_combobox_PySide6_demo.png en assets/
- [x] The window appears with the correct title and size
- [x] QComboBox and button are visible and aligned
- [x] Tooltips appear when hovering over each widget
- [x] Selecting an option and clicking the button shows the modal dialog
- [x] Widgets remain visible when resizing
- [x] Screenshot saved as qt_combobox_PySide6_demo.png in assets/
