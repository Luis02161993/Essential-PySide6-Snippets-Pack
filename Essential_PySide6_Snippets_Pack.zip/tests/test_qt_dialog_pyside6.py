import pytest
from PySide6.QtWidgets import QApplication
from docs.qt_dialog_PySide6 import CustomDialog


@pytest.fixture(scope="module")
def app():
    import sys

    app = QApplication.instance() or QApplication(sys.argv)
    yield app


@pytest.mark.parametrize(
    "lang,title",
    [
        ("en", "Custom QDialog - QtRapidKit"),
        ("es", "Diálogo Personalizado - QtRapidKit"),
    ],
)
def test_dialog_title(qapp, qtbot, lang, title):
    CustomDialog.language = lang
    dlg = CustomDialog()
    qtbot.addWidget(dlg)
    dlg.show()
    assert dlg.windowTitle() == title
    dlg.close()


@pytest.mark.parametrize("lang", ["en", "es"])
def test_dialog_resize_limits(qapp, qtbot, lang):
    CustomDialog.language = lang
    dlg = CustomDialog()
    qtbot.addWidget(dlg)
    dlg.show()
    assert dlg.minimumWidth() == 300
    assert dlg.minimumHeight() == 140
    assert dlg.maximumWidth() == 600
    assert dlg.maximumHeight() == 320
    dlg.close()


@pytest.mark.parametrize("lang", ["en", "es"])
def test_label_and_buttons_exist(qapp, qtbot, lang):
    CustomDialog.language = lang
    dlg = CustomDialog()
    qtbot.addWidget(dlg)
    dlg.show()
    labels = dlg.findChildren(type(dlg.label))
    assert any(isinstance(w, type(dlg.label)) for w in labels)
    buttons = dlg.findChildren(dlg.SmoothTooltipButton)
    assert len(buttons) == 2
    dlg.close()
