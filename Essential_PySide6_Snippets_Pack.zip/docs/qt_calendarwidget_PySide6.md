---
# QCalendarWidget (PySide6)

**Descripción / Description:**
- ES: Ventana principal con calendario y etiqueta que muestra la fecha seleccionada usando PySide6. Incluye layout profesional, tooltips y soporte bilingüe. Listo para integración comercial.
- EN: Main window with calendar and label showing the selected date using PySide6. Includes professional layout, tooltips, and bilingual support. Ready for commercial integration.

**Comando de ejecución / Execution command:**
```powershell
python docs/qt_calendarwidget_PySide6.py
```

**Checklist técnico / Technical checklist:**
- [x] Ventana con tamaño mínimo profesional
- [x] Calendario y etiqueta visibles y alineados
- [x] Tooltip en el calendario
- [x] Fácil de modificar textos y formato de fecha
- [x] Window with professional minimum size
- [x] Calendar and label visible and aligned
- [x] Tooltip on the calendar
- [x] Easy to modify texts and date format

**Checklist visual / Visual checklist:**
- [x] La ventana aparece con el título y tamaño correctos
- [x] El calendario y la etiqueta son visibles y alineados
- [x] El tooltip aparece al pasar el mouse sobre el calendario
- [x] Al seleccionar una fecha, la etiqueta se actualiza
- [x] Widgets permanecen visibles al redimensionar
- [x] Captura de pantalla guardada como qt_calendarwidget_PySide6_demo.png en assets/
- [x] The window appears with the correct title and size
- [x] Calendar and label are visible and aligned
- [x] Tooltip appears when hovering over the calendar
- [x] Selecting a date updates the label
- [x] Widgets remain visible when resizing
- [x] Screenshot saved as qt_calendarwidget_PySide6_demo.png in assets/
---
