"""
QHBoxLayout (PySide6) - Pruebas Automáticas / Automated Tests
-----------------------------------------------------------
EN: Automated tests for the QHBoxLayout snippet using pytest-qt. Includes launch and language tests (if supported). Professional coverage and bilingual docstring.
ES: Pruebas automáticas para el snippet QHBoxLayout usando pytest-qt. Incluye pruebas de lanzamiento y de idioma (si aplica). Cobertura profesional y docstring bilingüe.
"""
import pytest
from PySide6.QtWidgets import QApplication
from docs.qt_horizontal_layout_PySide6 import MainWindow

@pytest.mark.parametrize(
    "lang",
    [
        "en",
        "es",
    ] if hasattr(MainWindow, "language") else ["en"],
)
def test_mainwindow_launch_and_language(qtbot, lang):
    if hasattr(MainWindow, "language"):
        MainWindow.language = lang
    window = MainWindow()
    qtbot.addWidget(window)
    window.show()
    assert window.isVisible()
    assert window.windowTitle() != ""
    window.close()
