"""
QCheckBox (PySide6) - Pruebas Automáticas / Automated Tests
---------------------------------------------------------
EN: Automated tests for the QCheckBox snippet using pytest-qt. Includes launch, language, size limits, and widget existence tests. Professional coverage and bilingual docstring.
ES: Pruebas automáticas para el snippet QCheckBox usando pytest-qt. Incluye pruebas de lanzamiento, idioma, límites de tamaño y existencia de widgets. Cobertura profesional y docstring bilingüe.
"""
import pytest
from PySide6.QtWidgets import QApplication
from docs.qt_checkbox_PySide6 import MainWindow


@pytest.mark.parametrize(
    "lang,title",
    [
        ("en", "QCheckBox - QtRapidKit"),
        ("es", "QCheckBox - QtRapidKit"),
    ],
)
def test_mainwindow_title_and_launch(qtbot, lang, title):
    MainWindow.language = lang
    window = MainWindow()
    qtbot.addWidget(window)
    window.show()
    assert window.windowTitle() == title
    assert window.isVisible()
    window.close()


@pytest.mark.parametrize("lang", ["en", "es"])
def test_mainwindow_resize_limits(qtbot, lang):
    MainWindow.language = lang
    window = MainWindow()
    qtbot.addWidget(window)
    window.show()
    assert window.minimumWidth() >= 340
    assert window.minimumHeight() >= 170
    assert window.width() >= window.minimumWidth()
    assert window.height() >= window.minimumHeight()
    window.close()


@pytest.mark.parametrize("lang", ["en", "es"])
def test_checkboxes_exist(qtbot, lang):
    MainWindow.language = lang
    window = MainWindow()
    qtbot.addWidget(window)
    window.show()
    checkboxes = [w for w in window.findChildren(type(window.checkbox1))]
    assert checkboxes, "No CheckBoxes found"
    window.close()
