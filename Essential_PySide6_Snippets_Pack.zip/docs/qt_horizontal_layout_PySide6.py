
"""
QHBoxLayout (PySide6)

Bilingual Documentation / Documentación Bilingüe
------------------------------------------------
EN: Professional snippet to create a main window demonstrating a horizontal layout (QHBoxLayout) with three buttons, smooth tooltips, minimum/maximum size, and best practices for professional use in PySide6.

ES: Snippet profesional para crear una ventana principal que demuestra un layout horizontal (QHBoxLayout) con tres botones, tooltips suaves, tamaño mínimo/máximo y buenas prácticas para uso profesional en PySide6.

Example / Ejemplo:
------------------
EN:
    from docs.qt_horizontal_layout_PySide6 import MainWindow
    app = QApplication([])
    window = MainWindow()
    window.show()
    app.exec_()

ES:
    from docs.qt_horizontal_layout_PySide6 import MainWindow
    app = QApplication([])
    window = MainWindow()
    window.language = "es"
    window.show()
    app.exec_()
"""

from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QHBoxLayout,
    QPushButton,
    QMessageBox,
    QToolTip,
    QStatusBar,
    QStyleFactory,
)
from PySide6.QtCore import QTimer, QEvent
from PySide6.QtGui import QColor, QPalette, QEnterEvent
def set_auto_palette(app: QApplication) -> None:
    """
    EN: Set the application palette to match the system's dark/light mode automatically.
    ES: Ajusta la paleta de la aplicación para coincidir con el modo oscuro/claro del sistema automáticamente.
    """
    app.setStyle(QStyleFactory.create("Fusion"))
    app.setPalette(QApplication.style().standardPalette())
from typing import Optional
import sys


class SmoothTooltipButton(QPushButton):
    def __init__(self, text: str, tooltip: str, parent: Optional[QMainWindow] = None) -> None:
        super().__init__(text, parent)
        self._tooltip = tooltip
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._show_tooltip)
        self.setMouseTracking(True)

    def enterEvent(self, event: QEnterEvent) -> None:
        self._timer.start(80)
        super().enterEvent(event)

    def leaveEvent(self, event: QEvent) -> None:
        QToolTip.hideText()
        self._timer.stop()
        super().leaveEvent(event)

    def _show_tooltip(self) -> None:
        QToolTip.showText(self.mapToGlobal(self.rect().center()), self._tooltip, self)



class MainWindow(QMainWindow):
    """
    EN: Main window for QHBoxLayout snippet. Demonstrates a horizontal layout with three buttons, tooltips, and professional layout. Multilingual support included.
    ES: Ventana principal para el snippet QHBoxLayout. Demuestra un layout horizontal con tres botones, tooltips y layout profesional. Incluye soporte multilenguaje.
    """

    language: str = "en"  # Default language is English. Change to 'es' for Spanish.
    button_left: SmoothTooltipButton

    def __init__(self) -> None:
        super().__init__()
        if self.language == "es":
            self.setWindowTitle("QHBoxLayout (PySide6)")
            left_text = "Izquierda"
            left_tooltip = "Haz clic para mostrar el mensaje izquierdo"
            center_text = "Centro"
            center_tooltip = "Haz clic para mostrar el mensaje central"
            right_text = "Derecha"
            right_tooltip = "Haz clic para mostrar el mensaje derecho"
            info_title = "Información"
            info_left = "¡Botón izquierdo presionado!"
            info_center = "¡Botón central presionado!"
            info_right = "¡Botón derecho presionado!"
        else:
            self.setWindowTitle("QHBoxLayout (PySide6)")
            left_text = "Left"
            left_tooltip = "Click to show left message"
            center_text = "Center"
            center_tooltip = "Click to show center message"
            right_text = "Right"
            right_tooltip = "Click to show right message"
            info_title = "Info"
            info_left = "Left button clicked!"
            info_center = "Center button clicked!"
            info_right = "Right button clicked!"
        self.setMinimumSize(300, 120)
        self.setMaximumSize(600, 300)
        self.resize(400, 150)
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        layout = QHBoxLayout(central_widget)
        self.button_left = SmoothTooltipButton(left_text, left_tooltip, self)
        def on_left_clicked() -> None:
            QMessageBox.information(self, info_title, info_left)
        self.button_left.clicked.connect(on_left_clicked)
        layout.addWidget(self.button_left)
        button2 = SmoothTooltipButton(center_text, center_tooltip, self)
        def on_center_clicked() -> None:
            QMessageBox.information(self, info_title, info_center)
        button2.clicked.connect(on_center_clicked)
        layout.addWidget(button2)
        button3 = SmoothTooltipButton(right_text, right_tooltip, self)
        def on_right_clicked() -> None:
            QMessageBox.information(self, info_title, info_right)
        button3.clicked.connect(on_right_clicked)
        layout.addWidget(button3)
        status_bar = QStatusBar(self)
        self.setStatusBar(status_bar)



if __name__ == "__main__":
    app = QApplication(sys.argv)
    set_auto_palette(app)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
