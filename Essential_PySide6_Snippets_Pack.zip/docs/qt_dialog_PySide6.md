---
# QDialog (PySide6)

**Descripción / Description:**
- ES: Ventana de diálogo personalizada con dos botones y etiqueta usando PySide6. Incluye layout profesional, tooltips y validación visual. Bilingüe y lista para integración.
- EN: Custom dialog window with two buttons and a label using PySide6. Includes professional layout, tooltips, and visual validation. Bilingual and ready for integration.

**Comando de ejecución / Execution command:**
```powershell
python docs/qt_dialog_PySide6.py
```

**Checklist técnico / Technical checklist:**
- [x] Ventana de diálogo personalizada con dos botones y etiqueta
- [x] Layout profesional y tooltips
- [x] Fácil de modificar widgets y textos
- [x] Custom dialog window with two buttons and a label
- [x] Professional layout and tooltips
- [x] Easy to modify widgets and texts

**Checklist visual / Visual checklist:**
- [x] La ventana de diálogo aparece con el título correspondiente
- [x] La etiqueta y ambos botones son visibles y alineados verticalmente
- [x] Al hacer clic en OK o Cancelar, el diálogo se cierra correctamente
- [x] Se muestra un mensaje informativo tras aceptar o cancelar
- [x] Todos los widgets permanecen visibles al cambiar el tamaño
- [x] Guarda una captura como qt_dialog_PySide6_demo.png en assets/
- [x] The dialog window appears with the correct title
- [x] The label and both buttons are visible and vertically aligned
- [x] Clicking OK or Cancel closes the dialog correctly
- [x] An informative message is shown after accept or cancel
- [x] All widgets remain visible when resizing
- [x] Save a screenshot as qt_dialog_PySide6_demo.png in assets/
