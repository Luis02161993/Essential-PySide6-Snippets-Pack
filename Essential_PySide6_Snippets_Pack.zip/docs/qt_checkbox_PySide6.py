
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QCheckBox, QMessageBox, QStatusBar
)
from typing import Optional
import sys
from smooth_tooltip_button_and_palette import SmoothTooltipButton, set_auto_palette


# Clase principal profesional y bilingüe para QCheckBox (PySide6)
class MainWindow(QMainWindow):
    """
    EN: Main window for QCheckBox snippet. Demonstrates checkboxes and selection button with tooltips. All elements use a professional layout. Multilingual support included.
    ES: Ventana principal para el snippet QCheckBox. Demuestra casillas de verificación y botón de selección con tooltips. Todos los elementos usan un layout profesional. Incluye soporte multilenguaje.
    """

    language: str = "en"  # Default language is English. Change to 'es' for Spanish.
    checkboxes: list
    msg_title: str
    msg_none: str
    msg_selected: str

    def __init__(self) -> None:
        super().__init__()
        if type(self).language == "es":
            self.setWindowTitle("QCheckBox - QtRapidKit")
            checkbox_texts = ["Opción A", "Opción B", "Opción C"]
            checkbox_tooltips = [
                "Selecciona la opción A",
                "Selecciona la opción B",
                "Selecciona la opción C",
            ]
            button_text = "Mostrar selección"
            button_tooltip = "Haz clic para mostrar las opciones seleccionadas"
            msg_title = "Selección"
            msg_none = "Ninguna opción seleccionada."
            msg_selected = "Opciones seleccionadas: {}"
        else:
            self.setWindowTitle("QCheckBox - QtRapidKit")
            checkbox_texts = ["Option A", "Option B", "Option C"]
            checkbox_tooltips = [
                "Select option A",
                "Select option B",
                "Select option C",
            ]
            button_text = "Show Selection"
            button_tooltip = "Click to show selected options"
            msg_title = "Selection"
            msg_none = "No option selected."
            msg_selected = "Selected options: {}"
        self.setMinimumSize(350, 180)
        self.resize(400, 220)
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        self.checkboxes = []
        for idx, (text, tooltip) in enumerate(zip(checkbox_texts, checkbox_tooltips)):
            cb = QCheckBox(text)
            cb.setToolTip(tooltip)
            layout.addWidget(cb)
            self.checkboxes.append(cb)
            if idx == 0:
                self.checkbox1 = cb  # Para el test de atributo
        self.button = SmoothTooltipButton(button_text, button_tooltip)
        self.button.clicked.connect(self.show_selection)
        layout.addWidget(self.button)
        self.msg_title = msg_title
        self.msg_none = msg_none
        self.msg_selected = msg_selected
        # Añadir QStatusBar para grip profesional de redimensión
        status_bar = QStatusBar()
        self.setStatusBar(status_bar)

    def show_selection(self) -> None:
        selected = [cb.text() for cb in self.checkboxes if cb.isChecked()]
        if selected:
            QMessageBox.information(
                None, self.msg_title, self.msg_selected.format(", ".join(selected))
            )
        else:
            QMessageBox.information(None, self.msg_title, self.msg_none)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    set_auto_palette(app)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())





